<!DOCTYPE html>
<html>
<head>
<title>PHP DEMO DATABASE </title>
</head>
<body>

<?php echo "The time is " . date("h:i:sa") . " and today is " . date("Y/m/d") . "<br>"; 
echo 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; 
echo "<br>";
?>
<hr/>



<button type="button">Click Me!</button>

<input type=button 
value="Button Hello"
onClick="self.location='phpdatabase.php?varname=hello'">

<input type=button 
value="Button Home Index"
onClick="self.location='phpdatabase.php'">



<?php
// test here of varname passed for hello
$var_value = $_GET['varname'];
if (!empty($var_value))
if ( $var_value == "hello" )
{
  echo "<br>";
  echo "Clicked on Button ";
  echo $var_value;
  echo "<br>";
}
?>



<?php
if (!empty($_POST))
if (!empty($_POST["postdata"]))
{
  $myfile = fopen("database.asc", "ab") or die("Unable to open file!");
  fwrite($myfile, $_POST["postdata"] );
  fwrite($myfile, ";" );
  //fwrite($myfile, "\n" );
  fclose($myfile);
}
?>
<?php if (!empty($_POST)): ?>
    Your chat input line (post) is: <?php echo htmlspecialchars($_POST["postdata"]); ?>.<br>
<?php else: ?>
    <form action=<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?> method="post">
        Your database LN (post): <input type="text" name="postdata"><br>
        <input type="submit">
    </form>
<?php endif; ?>

<br>
<input type=button 
value="Button 0"
onClick="self.location='phpdatabase.php?varname=code0'">
<input type=button 
value="Button 1"
onClick="self.location='phpdatabase.php?varname=code1'">
<input type=button 
value="Button 2"
onClick="self.location='phpdatabase.php?varname=code2'">
<input type=button 
value="Button 3"
onClick="self.location='phpdatabase.php?varname=code3'">
<input type=button 
value="Button 4"
onClick="self.location='phpdatabase.php?varname=code4'">
<input type=button 
value="Button LF"
onClick="self.location='phpdatabase.php?varname=codelf'">
<hr>
<br>

<?php
$var_value = $_GET['varname'];
if (!empty($var_value))
if ( ($var_value == "code0" )
|| ($var_value == "code1" )
|| ($var_value == "code2" )
|| ($var_value == "code3" )
|| ($var_value == "code4" )
)
{
  echo "<br>";
  echo "Clicked on Button ";
  echo $var_value;
  echo "<br>";
  $myfile = fopen("database.asc", "ab") or die("Unable to open file!");
  if ($var_value == "code0" ) fwrite($myfile, "0" );
  else if ($var_value == "code1" ) fwrite($myfile, "0.75" );
  else if ($var_value == "code2" ) fwrite($myfile, "1.5" );
  else if ($var_value == "code3" ) fwrite($myfile, "2.25" );
  else if ($var_value == "code4" ) fwrite($myfile, "3" );
  fwrite($myfile, ";" );
  fclose($myfile);
}
?>

<?php
$var_value = $_GET['varname'];
if (!empty($var_value))
if ($var_value == "codelf" )
{
  echo "<br>";
  echo "Clicked on Button ";
  echo $var_value;
  echo "<br>";
  $myfile = fopen("database.asc", "ab") or die("Unable to open file!");
  fwrite($myfile, "\n" );
  fclose($myfile);
}
?>





<?php
// VISUAL
if (! file_exists("database.asc"))
{
  echo "File database.asc Not Found <br>" ;
}
else
{
$maxi = 0;
$counter = 0;
echo "File database.asc Found:<br>" ;
$handle = fopen("database.asc", "r");
if ($handle) {
    while (($line = fgets($handle)) !== false) {
        // process the line read.
        echo "- ";
        echo $line ;
        $counter++;
      
        
        $str = 'abcdef';
        // echo $str[0];                 // a
        
        // list($col1, $col2, $col3, $col4, $col5) =  split(":", $line , 5);
        settype($j, "integer");
        $j=0;
        settype($tsum, "float");
        $tsum=0;
        $charo= "";
        //echo "<br>  ";
        for ($i=0; $i < strlen($line) ; $i++)
        {  
            if ( $line[$i] == ';' )  $j++;
            if ( $line[$i] == ';' )
            {
               $float = (float)$charo;
               $tsum = $tsum + $float;   
               $charo = "";
            }
            else
               $charo = $charo . $line[$i];
            //echo $line[$i];
        }
        if ( $j-1 >= 0 )
        {
           echo "   [n=";
           echo $j-1;
           echo "]";
           echo "(Sum=" . $tsum . ")" ;
           
           if ( $counter == 1 ) $maxi = $tsum;
           $padded = sprintf('%0.2f', $tsum / $maxi *100 );
           echo "(Div=" . $padded . ")" ;
        }
        echo "<br>";
        
    }

    fclose($handle);
} else {
    // error opening the file.
} 
}
?>
<hr>
<br>


<br>
<input type=button 
value="Button Delete Database"
onClick="self.location='phpdatabase.php?varname=deldb'">
<?php
// test here of varname passed to unlink (delete in C) a file.
$var_value = $_GET['varname'];
if (!empty($var_value))
if ($var_value == "deldb" )
{
  echo "<br>";
  echo "Clicked on Button ";
  echo $var_value;
  echo "<br>";
  if (file_exists("database.asc")) 
     unlink( "database.asc" );
}
?>
<br>
<br>
<br>
<br>


 
---End Of Page Bye!  ---<br>
End Of Page<br>

 
<input type=button 
value="Button Home Index"
onClick="self.location='phpdatabase.php'">


</body>
</html>


