<!DOCTYPE html>
<html>
<head>
<title>EDUCATIONAL PHP LEARNING CODE - BUTTON AND POST </title>
</head>
<body>

-- EDUCATIONAL PHP LEARNING CODE - BUTTON AND POST  --<br>
<?php echo "The time is " . date("h:i:sa") . " and today is " . date("Y/m/d") . "<br>"; 
echo 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; 
echo "<br>";
?>
<hr/>


<?php
// this creates a new file
$myfile = fopen("editor.asc", "w") or die("Unable to open file!");
fwrite($myfile, "Hello World\n");
fwrite($myfile, "This is a test of ascii file\n");
$txt = "John Doe\n";
fwrite($myfile, $txt);
$txt = "Jane Doe\n";
fwrite($myfile, $txt);
fclose($myfile);
?>


 



<button type="button">Click Me!</button>

<input type=button 
value="Button Hello"
onClick="self.location='index.php?varname=hello'">

<input type=button 
value="Button Home Index"
onClick="self.location='index.php'">

<input type=button 
value="Button Clear"
onClick="self.location='index.php?varname=clear'">

<?php
// test here of varname passed for hello
$var_value = $_GET['varname'];
if (!empty($var_value))
if ( $var_value == "hello" )
{
  echo "<br>";
  echo "Clicked on Button ";
  echo $var_value;
  echo "<br>";
}
?>

<?php
// test here of varname passed to unlink (delete in C) a file.
$var_value = $_GET['varname'];
if (!empty($var_value))
if ($var_value == "clear" )
{
  echo "<br>";
  echo "Clicked on Button ";
  echo $var_value;
  echo "<br>";
  if (file_exists("chat.asc")) 
     unlink( "chat.asc" );
}
?>
<hr>
<br>



<?php
if (!empty($_POST))
if (!empty($_POST["postdata"]))
{
  $myfile = fopen("database.asc", "ab") or die("Unable to open file!");
  fwrite($myfile, $_POST["postdata"] );
  fwrite($myfile, ";" );
  //fwrite($myfile, "\n" );
  fclose($myfile);
}
?>
<?php if (!empty($_POST)): ?>
    Your chat input line (post) is: <?php echo htmlspecialchars($_POST["postdata"]); ?>.<br>
<?php else: ?>
    <form action=<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?> method="post">
        Your database LN (post): <input type="text" name="postdata"><br>
        <input type="submit">
    </form>
<?php endif; ?>

<input type=button 
value="Button 0"
onClick="self.location='index.php?varname=code0'">
<input type=button 
value="Button 1"
onClick="self.location='index.php?varname=code1'">
<input type=button 
value="Button 2"
onClick="self.location='index.php?varname=code2'">
<input type=button 
value="Button 3"
onClick="self.location='index.php?varname=code3'">
<input type=button 
value="Button 4"
onClick="self.location='index.php?varname=code4'">
<input type=button 
value="Button LF"
onClick="self.location='index.php?varname=codelf'">
<hr>
<br>

<?php
$var_value = $_GET['varname'];
if (!empty($var_value))
if ( ($var_value == "code0" )
|| ($var_value == "code1" )
|| ($var_value == "code2" )
|| ($var_value == "code3" )
|| ($var_value == "code4" )
)
{
  echo "<br>";
  echo "Clicked on Button ";
  echo $var_value;
  echo "<br>";
  $myfile = fopen("database.asc", "ab") or die("Unable to open file!");
  if ($var_value == "code0" ) fwrite($myfile, "0" );
  else if ($var_value == "code1" ) fwrite($myfile, "0.75" );
  else if ($var_value == "code2" ) fwrite($myfile, "1.5" );
  else if ($var_value == "code3" ) fwrite($myfile, "2.25" );
  else if ($var_value == "code4" ) fwrite($myfile, "3" );
  fwrite($myfile, ";" );
  fclose($myfile);
}
?>

<?php
$var_value = $_GET['varname'];
if (!empty($var_value))
if ($var_value == "codelf" )
{
  echo "<br>";
  echo "Clicked on Button ";
  echo $var_value;
  echo "<br>";
  $myfile = fopen("database.asc", "ab") or die("Unable to open file!");
  fwrite($myfile, "\n" );
  fclose($myfile);
}
?>





<?php
// VISUAL
if (! file_exists("database.asc"))
{
  echo "File database.asc Not Found <br>" ;
}
else
{
echo "File database.asc Found:<br>" ;
$handle = fopen("database.asc", "r");
if ($handle) {
    while (($line = fgets($handle)) !== false) {
        // process the line read.
        echo $line ;
        echo "<br>";
    }

    fclose($handle);
} else {
    // error opening the file.
} 
}
?>
<hr>
<br>

 




<?php
// VISUAL
if (! file_exists("chat.asc"))
{
  echo "File chat.asc Not Found <br>" ;
}
else
{
echo "File chat.asc Found:<br>" ;
$handle = fopen("chat.asc", "r");
if ($handle) {
    while (($line = fgets($handle)) !== false) {
        // process the line read.
        echo $line ;
        echo "<br>";
    }

    fclose($handle);
} else {
    // error opening the file.
} 
}
?>
<hr>
<br>

 

 


<?php
// Check if file already exists
if (file_exists("editor.asc")) 
    echo "Yes, the file exists.<br>";
else 
    echo "No, the file does not exist.<br>";
?>
<?php
// Check if file already exists
if (file_exists("editor.blabla")) 
    echo "Yes, the file exists.<br>";
else 
    echo "No, the file does not exist.<br>";
?>
<br>
<hr/>

 
<p>View database.asc <a href="database.asc">Link Click</a></p>
<hr>
<br>




<?php if (!empty($_POST)): ?>
    Welcome, your name (post) is: <?php echo htmlspecialchars($_POST["name"]); ?>!<br>
    Your email (post) is: <?php echo htmlspecialchars($_POST["email"]); ?>.<br>
<?php else: ?>
    <form action=<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?> method="post">
        Name (post): <input type="text" name="name"><br>
        Email (post): <input type="text" name="email"><br>
        <input type="submit">
    </form>
<?php endif; ?>
<hr>
<br>



<?php if (!empty($_POST)): ?>
    Your message (post) is: <?php echo htmlspecialchars($_POST["pstmsg"]); ?>.<br>
<?php else: ?>
    <form action=<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?> method="post">
        Your message (post): <input type="text" name="pstmsg"><br>
        <input type="submit">
    </form>
<?php endif; ?>
<hr>
<br>




<?php
if (!empty($_POST))
if (!empty($_POST["postchat"]))
{
  $myfile = fopen("chat.asc", "ab") or die("Unable to open file!");
  fwrite($myfile, $_POST["postchat"] );
  fwrite($myfile, "\n" );
  fclose($myfile);
}
?>
<?php if (!empty($_POST)): ?>
    Your chat input line (post) is: <?php echo htmlspecialchars($_POST["postchat"]); ?>.<br>
<?php else: ?>
    <form action=<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?> method="post">
        Your chat msg (post): <input type="text" name="postchat"><br>
        <input type="submit">
    </form>
<?php endif; ?>
<hr>
<br>







<br>
<h3> Bookmarks </h3>
<a href="http://www.google.com"> Google Search </a><br>
<br>
<br>





<hr/>
---End Of Page Bye!  ---<br>
End Of Page<br>

<!--
<img src="https://upload.wikimedia.org/wikipedia/commons/d/dd/Linux_logo.jpg" >
-->

<input type=button 
value="Button Home Index"
onClick="self.location='index.php'">


<!--
-Refresh 5secs-<br>
<meta http-equiv="refresh" content="5" />  
-->

</body>
</html>


